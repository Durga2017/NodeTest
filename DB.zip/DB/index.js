var express    = require("express");
var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : 'root',
  database : 'training'
});
var app = express();

//start
var bodyParser = require("body-parser");

app.use(bodyParser.urlencoded({extended:false}))

app.get('/',function(req,res){
res.sendFile(__dirname+'/index.html');
});
app.post('/submit-users-data',function(req,res) {
	console.log(req.body);
	
	
	  var post = {
        id: req.body.firstname,
        name: req.body.lastname
    };


connection.connect(function(err){
if(!err) {
    console.log("Database is connected ... nn");    
} else {
    console.log("Error connecting database ... nn");    
}
});

app.listen(3000);


exports.mysqli = function(data,row)
{
     k = mysqli[row];    
     for(var i in data)
     {        
     	k = k.replace(new RegExp('{{'+i+'}}', 'g'), data[i]);    	
     }
     return k;
}

var mysqli = [];

mysqli[5]  = 'select * from users';
mysqli['selectuserbyid'] = 'select * from users where id=?'
mysqli['users'] = 'insert into users(name,email,username,phone,street,city,zipcode) values(?,?,?,?,?,?,?)';
mysqli['users_Update'] = 'update users set name=?,email=?,username=?,phone=?,street=?,city=?,zipcode=? where id=?';
mysqli['users_delete'] = 'DELETE FROM users WHERE id = ?';
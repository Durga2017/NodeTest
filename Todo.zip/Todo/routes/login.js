var express = require('express');
var common = require('../module/common');
var app = express.Router();
var q = require('q');
var pagination = require('pagination');
//required js


app.get(['/login','/login/:error'],function(req,res)
{
	req.body.error = $arr['error'] =  (typeof(req.param('error')) === 'undefined') ? '' : req.param('error');
	common.tplFile('customer/login.tpl');
	common.headerSet(1);
	common.loadTemplateHeader(req,res,$arr);
});

app.post(['/login/save'],function(req,res) {
	if(typeof(req.body.autologin)=='undefined')
	common.checkLogin(req,res,1);
	else
	req.session.autologin = req.body.autologinoption;

	var login = require('../module/login');
	function processObject(row)
	{
		if(row.length > 0) {
			if(row[0].active_status =='Active') {
				delete req.session.person_id;
				delete req.session.email_id;
				delete session;
				req.session.email = row[0].email_id;
				req.session.tpermission = 'no';
				$arr.loged = req.session;
				res.writeHead(302, {
					'Location': '/'
				});
				res.end();
			}
			else {
				res.writeHead(302, {
					'Location': '/admincp/login/Invalid login'
				});
				res.end();
			} 
		}  
		else {
			res.writeHead(302, {
				'Location': '/admin/login/Invalid login'
			});
			res.end();
		}  
	} 
	var userprocess = login.process(req,config.mysql,processObject); 
});

module.exports = app;